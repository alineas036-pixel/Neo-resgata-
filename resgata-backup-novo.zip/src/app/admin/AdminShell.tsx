
"use client";

import { useState } from "react";
import styles from "./admin.module.css";

const menuItems = [
  { id: "overview", label: "Visão geral", icon: "▦" },
  { id: "users", label: "Usuários", icon: "♙" },
  { id: "finance", label: "Financeiro", icon: "◈" },
  { id: "debts", label: "Dívidas e pagamentos", icon: "▤" },
  { id: "subscriptions", label: "Assinaturas", icon: "▣" },
  { id: "reports", label: "Relatórios", icon: "▥" },
  { id: "security", label: "Segurança e acessos", icon: "◇" },
  { id: "settings", label: "Configurações", icon: "⚙" },
];

export default function AdminShell({
  children,
}: {
  children: React.ReactNode;
}) {
  const [active, setActive] = useState("overview");
  const [collapsed, setCollapsed] = useState(false);

  const selected = menuItems.find((item) => item.id === active);

  return (
    <div className={styles.adminLayout}>
      <aside
        className={`${styles.sidebar} ${
          collapsed ? styles.sidebarCollapsed : ""
        }`}
      >
        <div className={styles.brand}>
          <div className={styles.brandIcon}>R+</div>
          {!collapsed && (
            <div>
              <strong>RESGATA+</strong>
              <small>ADMINISTRAÇÃO</small>
            </div>
          )}
        </div>

        <button
          type="button"
          className={styles.collapseButton}
          onClick={() => setCollapsed(!collapsed)}
          aria-label={collapsed ? "Expandir menu" : "Recolher menu"}
        >
          {collapsed ? "→" : "←"}
        </button>

        <nav className={styles.sidebarNav} aria-label="Menu administrativo">
          {!collapsed && <span className={styles.menuLabel}>MENU PRINCIPAL</span>}

          {menuItems.map((item) => (
            <button
              type="button"
              key={item.id}
              title={collapsed ? item.label : undefined}
              className={`${styles.menuItem} ${
                active === item.id ? styles.menuItemActive : ""
              }`}
              onClick={() => setActive(item.id)}
            >
              <span className={styles.menuIcon}>{item.icon}</span>
              {!collapsed && <span>{item.label}</span>}
            </button>
          ))}
        </nav>

        <a
          href="/dashboard"
          className={styles.sidebarBack}
          title={collapsed ? "Voltar ao aplicativo" : undefined}
        >
          <span>↗</span>
          {!collapsed && <span>Voltar ao aplicativo</span>}
        </a>
      </aside>

      <main className={styles.adminMain}>
        <header className={styles.adminTopbar}>
          <div>
            <span className={styles.topbarLabel}>RESGATA+ / ADMIN</span>
            <h1>{selected?.label}</h1>
          </div>
          <span className={styles.adminBadge}>Administrador</span>
        </header>

        <section className={styles.adminContent}>
          {active === "overview" ? (
            children
          ) : (
            <div className={styles.modulePlaceholder}>
              <span className={styles.placeholderIcon}>
                {selected?.icon}
              </span>
              <h2>{selected?.label}</h2>
              <p>
                Este módulo será conectado aos dados reais do Supabase
                na próxima etapa.
              </p>
              <span className={styles.comingSoon}>Em preparação</span>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
